// Configuration des questions par thème
const questionsByTheme = {
    economie: {
        question: "💼 Quel modèle économique préférez-vous ?",
        options: [
            { value: "liberal", label: "Libéral", desc: "Moins d'État, plus de marché libre" },
            { value: "social", label: "Social", desc: "État protecteur, redistribution" },
            { value: "mixte", label: "Mixte", desc: "Équilibre marché/protection" },
            { value: "protectionniste", label: "Protectionniste", desc: "Priorité production nationale" }
        ]
    },
    environnement: {
        question: "🌍 Quelle politique environnementale soutenez-vous ?",
        options: [
            { value: "ecologiste", label: "Écologiste", desc: "Priorité absolue transition verte" },
            { value: "modere", label: "Modéré", desc: "Transition progressive" },
            { value: "sceptique", label: "Sceptique", desc: "Priorité à l'économie" }
        ]
    },
    sante: {
        question: "🏥 Comment doit être géré le système de santé ?",
        options: [
            { value: "universelle", label: "Universelle", desc: "Gratuite pour tous, 100% public" },
            { value: "mixte", label: "Mixte", desc: "Public renforcé + privé" },
            { value: "privatisee", label: "Privatisée", desc: "Assurances privées" }
        ]
    },
    securite: {
        question: "🚔 Quelle approche de la sécurité privilégiez-vous ?",
        options: [
            { value: "tres_ferme", label: "Très ferme", desc: "Tolérance zéro" },
            { value: "ferme", label: "Ferme", desc: "Renforcement moyens police" },
            { value: "modere", label: "Modéré", desc: "Équilibre répression/prévention" },
            { value: "prevention", label: "Prévention", desc: "Traiter les causes sociales" }
        ]
    },
    europe: {
        question: "🇪🇺 Quelle est votre position sur l'Union Européenne ?",
        options: [
            { value: "pro_europeen", label: "Pro-européen", desc: "Renforcer l'intégration" },
            { value: "reforme_traites", label: "Réformer", desc: "Changer les règles européennes" },
            { value: "eurosceptique", label: "Eurosceptique", desc: "Sortir ou retrouver souveraineté" }
        ]
    },
    immigration: {
        question: "🌐 Quelle politique d'immigration souhaitez-vous ?",
        options: [
            { value: "tres_restrictif", label: "Très restrictif", desc: "Immigration quasi-nulle" },
            { value: "restrictif", label: "Restrictif", desc: "Quotas stricts" },
            { value: "modere", label: "Modéré", desc: "Contrôle avec humanité" },
            { value: "humaniste", label: "Humaniste", desc: "Accueil et intégration" }
        ]
    },
    fiscalite: {
        question: "💰 Quelle politique fiscale privilégiez-vous ?",
        options: [
            { value: "baisse_impots", label: "Baisse générale", desc: "Moins d'impôts pour tous" },
            { value: "impot_progressif", label: "Progressif renforcé", desc: "Plus les riches paient" },
            { value: "taxation_richesse", label: "Taxer les riches", desc: "Impôts élevés hauts revenus" }
        ]
    },
    retraite: {
        question: "👴 Quelle réforme des retraites souhaitez-vous ?",
        options: [
            { value: "retour_60_ans", label: "Retour à 60 ans", desc: "Retraite à 60 ans pour tous" },
            { value: "maintien_62_ans", label: "Maintien à 62 ans", desc: "Conserver l'âge actuel" },
            { value: "recul_age", label: "Recul progressif", desc: "64-65 ans pour équilibrer" }
        ]
    },
    energie: {
        question: "⚡ Quelle politique énergétique préférez-vous ?",
        options: [
            { value: "pro_nucleaire", label: "Pro-nucléaire", desc: "Développer le nucléaire" },
            { value: "mixte", label: "Mix énergétique", desc: "Équilibre nucléaire/renouvelables" },
            { value: "sortie_nucleaire", label: "Sortie nucléaire", desc: "100% renouvelables" }
        ]
    },
    education: {
        question: "📚 Quelle politique d'éducation souhaitez-vous ?",
        options: [
            { value: "gratuite_investissement", label: "Investissement massif", desc: "Gratuité et augmentation moyens" },
            { value: "reformiste", label: "Réformes", desc: "Adapter l'école au monde moderne" },
            { value: "traditionnelle", label: "Retour fondamentaux", desc: "Lecture, écriture, autorité" },
            { value: "merite", label: "Méritocratie", desc: "Excellence et sélection" }
        ]
    }
};

// Variables globales
let selectedThemes = [];
let currentQuestion = 0;
let reponses = {};
let activeQuestions = [];

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    setupThemeSelection();
    updateSelectedCount();
});

// Gestion de la sélection des thèmes
function setupThemeSelection() {
    const themeCheckboxes = document.querySelectorAll('input[name="theme"]');
    const selectAllBtn = document.getElementById('selectAll');
    const deselectAllBtn = document.getElementById('deselectAll');
    const startBtn = document.getElementById('startQuestionnaire');

    themeCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateSelectedCount);
    });

    selectAllBtn.addEventListener('click', () => {
        themeCheckboxes.forEach(cb => cb.checked = true);
        updateSelectedCount();
    });

    deselectAllBtn.addEventListener('click', () => {
        themeCheckboxes.forEach(cb => cb.checked = false);
        updateSelectedCount();
    });

    startBtn.addEventListener('click', startQuestionnaire);
}

function updateSelectedCount() {
    const checked = document.querySelectorAll('input[name="theme"]:checked');
    document.getElementById('countSelected').textContent = checked.length;
    
    // Mettre à jour l'état des cartes
    document.querySelectorAll('.theme-card').forEach(card => {
        const checkbox = card.querySelector('input[type="checkbox"]');
        if (checkbox.checked) {
            card.classList.add('selected');
        } else {
            card.classList.remove('selected');
        }
    });
}

function startQuestionnaire() {
    const checkedThemes = document.querySelectorAll('input[name="theme"]:checked');
    
    if (checkedThemes.length < 3) {
        alert('Veuillez sélectionner au moins 3 thèmes pour obtenir des résultats pertinents.');
        return;
    }

    // Récupérer les thèmes sélectionnés
    selectedThemes = Array.from(checkedThemes).map(cb => cb.value);
    
    // Construire la liste des questions actives
    activeQuestions = selectedThemes.map(theme => ({
        theme: theme,
        ...questionsByTheme[theme]
    }));

    // Afficher l'écran du questionnaire
    document.getElementById('themeSelection').style.display = 'none';
    document.getElementById('questionnaireScreen').style.display = 'block';
    document.getElementById('totalQuestions').textContent = activeQuestions.length;

    // Générer les questions
    generateQuestions();
    showQuestion(0);
    setupNavigation();
}

function generateQuestions() {
    const container = document.getElementById('questionsContainer');
    container.innerHTML = '';

    activeQuestions.forEach((q, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'question';
        questionDiv.dataset.question = index + 1;
        questionDiv.style.display = 'none';

        let optionsHTML = '';
        q.options.forEach(opt => {
            optionsHTML += `
                <label class="option-card">
                    <input type="radio" name="${q.theme}" value="${opt.value}" required>
                    <span class="option-content">
                        <strong>${opt.label}</strong>
                        <small>${opt.desc}</small>
                    </span>
                </label>
            `;
        });

        questionDiv.innerHTML = `
            <h2>${index + 1}. ${q.question}</h2>
            <div class="options">${optionsHTML}</div>
        `;

        container.appendChild(questionDiv);
    });
}

function showQuestion(index) {
    const questions = document.querySelectorAll('.question');
    questions.forEach(q => q.style.display = 'none');
    if (questions[index]) {
        questions[index].style.display = 'block';
    }
    updateProgress();
    updateButtons();
}

function setupNavigation() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');

    nextBtn.addEventListener('click', nextQuestion);
    prevBtn.addEventListener('click', previousQuestion);
    
    document.getElementById('questionnaire').addEventListener('submit', function(e) {
        e.preventDefault();
        calculateResults();
    });
}

function nextQuestion() {
    const currentQ = document.querySelector(`[data-question="${currentQuestion + 1}"]`);
    const selected = currentQ.querySelector('input[type="radio"]:checked');
    
    if (!selected) {
        alert('Veuillez sélectionner une option.');
        return;
    }

    // Sauvegarder la réponse
    const theme = activeQuestions[currentQuestion].theme;
    reponses[theme] = selected.value;

    if (currentQuestion < activeQuestions.length - 1) {
        currentQuestion++;
        showQuestion(currentQuestion);
    }
}

function previousQuestion() {
    if (currentQuestion > 0) {
        currentQuestion--;
        showQuestion(currentQuestion);
    }
}

function updateProgress() {
    const progress = ((currentQuestion + 1) / activeQuestions.length) * 100;
    document.getElementById('progressBar').style.width = progress + '%';
    document.getElementById('questionNumber').textContent = currentQuestion + 1;
}

function updateButtons() {
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');

    prevBtn.style.display = currentQuestion > 0 ? 'block' : 'none';

    if (currentQuestion === activeQuestions.length - 1) {
        nextBtn.style.display = 'none';
        submitBtn.style.display = 'block';
    } else {
        nextBtn.style.display = 'block';
        submitBtn.style.display = 'none';
    }
}

function calculateResults() {
    // Vérifier que toutes les questions ont été répondues
    if (Object.keys(reponses).length < activeQuestions.length) {
        alert('Veuillez répondre à toutes les questions.');
        return;
    }

    // Charger les données et calculer
    fetch('data/partis.json')
        .then(response => response.json())
        .then(data => {
            const partis = data.partis;
            
            partis.forEach(parti => {
                let score = 0;
                let details = [];
                
                for (const theme in reponses) {
                    if (parti.positions[theme] === reponses[theme]) {
                        score += 1;
                        details.push(theme);
                    }
                }
                
                parti.score = score;
                parti.pourcentage = Math.round((score / activeQuestions.length) * 100);
                parti.themesAccord = details;
            });

            partis.sort((a, b) => b.score - a.score);

            sessionStorage.setItem('resultats', JSON.stringify(partis));
            sessionStorage.setItem('reponses', JSON.stringify(reponses));
            sessionStorage.setItem('totalQuestions', activeQuestions.length);

            window.location.href = 'results-v2.html';
        })
        .catch(error => {
            console.error('Erreur:', error);
            alert('Une erreur est survenue.');
        });
}